function U = CG2_sub( FTF1,FTF2,FTF3,Ak,H,U0,sf,s0,fft_B,mu,cg_iter )
% optimize the dictionaries via Conjugate gradient 
 r0 = PTPx( U0,fft_B,s0,sf )*Ak*FTF1*Ak'+U0*Ak*FTF2*Ak'+U0*Ak*FTF3*Ak'+mu*U0-H;  
 p0 = -r0;
 for i = 1:cg_iter
     Ap = PTPx( p0,fft_B,s0,sf )*Ak*FTF1*Ak'+p0*Ak*FTF2*Ak'+p0*Ak*FTF3*Ak'+mu*p0; % AP
     pp1 = p0(:)'*Ap(:);

     a = (r0(:)')*r0(:)/pp1;
     U = U0+a*p0;
     r1 = r0+a*Ap;
     b1 = (r1(:)'*r1(:))/(r0(:)'*r0(:));
     p1 = -r1+b1*p0;
    
     p0 = p1;
     r0 = r1;
     U0 = U;
     if norm(r0)<=0.01
         break;
     end
 end
 
 
