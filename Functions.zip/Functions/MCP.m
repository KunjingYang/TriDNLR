function y = MCP(x,c,gama)
   n = length(x);
   y = zeros(1,n);
   for i = 1:n
      if abs(x(i)) <= c*gama
          y(i) = c*abs(x(i))-x(i)^2/(2*gama);
      else
          y(i) = c^2*gama/2;
      end
   end