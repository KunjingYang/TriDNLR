function [ E ] = CG1_sub( FTF1,FTF2,FTF3,U0,U0_hat,mu,H,E0 ,cg_iter)
% optimize the dictionaries via Conjugate gradient 
 UTU = U0'*U0;
 UHTUH = U0_hat'*U0_hat;
 r0 = UHTUH*E0*FTF1+UTU*E0*FTF2+UTU*E0*FTF3+mu*E0-H;  % ��ʼ���в�
 p0 = -r0;
 for i=1:cg_iter
    Ap = UHTUH*p0*FTF1+UTU*p0*FTF2+UTU*p0*FTF3+mu*p0;
    pp1 = p0(:)'*Ap(:);

    a=(r0(:)')*r0(:)/pp1;
         E=E0+a*p0;
         r1=r0+a*Ap;
         
         b1=(r1(:)'*r1(:))/(r0(:)'*r0(:));
         p1=-r1+b1*p0;
     p0=p1;
     r0=r1;
     E0=E;
     if norm(r0)<=0.01
         break;
     end
 end