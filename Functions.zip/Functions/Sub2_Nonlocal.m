function G = Sub2_Nonlocal(S,Gk,mu,para,eta)
fprintf(' Sub2_Nonlocal is running ... ');
%%  
    Oi=zeros(size(S));
    G = S;
    [W,H,L] = size(S);
    patch_size = 8;
    overlap    = 4;
    K = 50;
    bparams.block_sz   = [patch_size, patch_size];
    bparams.overlap_sz = [overlap overlap];
    num1 = (W-patch_size)/(patch_size-overlap)+1;
    num2 = (H-patch_size)/(patch_size-overlap)+1;
    bparams.block_num = [num1 num2]; 
    fkmeans_omaxpt.careful = 1;
    
    PK=zeros(W,H,L); 
    L_fix_fft=fft(Gk,[],3);
    for j = 1:L
        [U,B,V] = svd(L_fix_fft(:,:,j),'econ');
        B = diag(B);
        B = tidu(B,para.gama);
        r = length(find(B~=0));
        B = B(1:r);
        PK(:,:,j) = U(:,1:r)*diag(B)*V(:,1:r)';
    end
    PK = ifft(PK,[],3);  % grad H
%%
    for i = 1:5
        N0 = (eta*Gk+para.tao*PK+para.rho*G-Oi)/(eta+para.rho);
        predenoised_blocks = ExtractBlocks(N0, bparams);
        Z_block = ExtractBlocks(N0, bparams);
        Y2 = Unfold(predenoised_blocks,size(predenoised_blocks),4);
        [label ] = fkmeans(Y2,K,fkmeans_omaxpt);
        for mn=1:max(label)
            gg = label == mn;
            XES=predenoised_blocks(:,:,:,gg);
            [a, b, c, d ]=size(XES);
            XES = reshape(XES,[a b c*d]);
            [N11] = prox_tnn(XES,para.tao/(para.rho+eta));
            N11=reshape(N11,[a b c d]); 
            Z_block(:,:,:,gg)=N11;
         end
         N1 = JointBlocks(Z_block, bparams);  
         G = (mu*S+para.rho*N1+Oi)/(para.rho+mu);   
         Oi = Oi+para.rho*(N1-G);
         if tnorm(G-N1)<= 3e-3*tnorm(S)||i == 5
             fprintf('sub2_iteration = %d \n',i);
             break
         end
    end