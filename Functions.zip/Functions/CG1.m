function D = CG1( B,P3,T3,Y3,Z3,lambda,beta,D0 )
% optimize the dictionaries via Conjugate gradient 
 [m,~] = size(B);
 H = Y3*B'+lambda*P3'*Z3*T3'+beta*D0/2;
 r0 = D0*(B*B'+beta/2*eye(m))+lambda*(P3'*P3)*D0*(T3*T3')-H;  % ��ʼ���в�
 p0 = -r0;
 for i=1:100
    Ap = p0*(B*B'+beta/2*eye(m))+lambda*(P3'*P3)*p0*(T3*T3');
    pp1 = p0(:)'*Ap(:);

    a=(r0(:)')*r0(:)/pp1;
         D=D0+a*p0;
         r1=r0+a*Ap;
         
         b1=(r1(:)'*r1(:))/(r0(:)'*r0(:));
         p1=-r1+b1*p0;
     p0=p1;
     r0=r1;
     D0=D;
     if norm(r0)<=0.01
        % fprintf('k=%d',i);
         break;
     end
 end