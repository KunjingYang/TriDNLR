function [Tur,ABC,UVW] = Sub1_TriBFus(Y,Z,Mk,T,BW,BH,sf,s0,mu,eta,Rdims,para,D,abc,uvw,n)
fprintf(' Sub1_TriBFus is running ... ');
gamma = para.gamma;   r = para.r;  lambda = para.lambda;

%% Initialization
[w,h,L] = size(Y); [W,H,s] = size(Z);  LL = size(D,2); 
R1 = Rdims(1);     R2 = Rdims(2);      R3 = Rdims(3);

U0 = uvw{1};     V0 = uvw{2};      W0 = uvw{3};
U0 = ifft( fft(U0).*repmat(BW,[1 size(U0,2)])); U0_hat = U0(s0:sf:end,:);  
V0 = ifft(fft(V0).*repmat(BH,[1 size(V0,2)]));  V0_hat = V0(s0:sf:end,:);
DW0 = D*W0;    DW0_hat = T*DW0; 
               
A_hat = abc{1};       Ah = reshape(A_hat,[r,R1*r]);
B_hat = abc{2};       Bh = reshape(B_hat,[r,R2*r]);
C_hat = abc{3};       Ch = reshape(C_hat,[r,R3*r]);

%% Main iterate
for iter=1:100
    %% Update Ah and U ...
    NN = reshape(permute(reshape(reshape(Ch,[r*R3,r])*Bh,[r,R3,R2,r]),[1,4,3,2]),[r*r,R2*R3]);
    
    FTF1 = reshape(reshape(reshape(reshape(NN,[r*r*R2,R3])',[R3*r*r,R2])*(V0_hat')*V0_hat,[R3,r*r*R2])'*(DW0')*DW0,[r*r,R2*R3]) * NN';  
    FTF2 = reshape(reshape(reshape(reshape(NN,[r*r*R2,R3])',[R3*r*r,R2])*(V0')*V0,[R3,r*r*R2])'*(DW0_hat')*DW0_hat,[r*r,R2*R3]) * NN';
    FTF3 = reshape(reshape(reshape(reshape(NN,[r*r*R2,R3])',[R3*r*r,R2])*(V0')*V0,[R3,r*r*R2])'*(W0')*W0,[r*r,R2*R3]) * NN';
    
    YF1 = (NN * reshape((reshape((reshape(Y,[w*h,L])*DW0)',[R3*w,h])*V0_hat)',[R2*R3,w]))'; % [w,r*r]
    ZF2 = (NN * reshape((reshape((reshape(Z,[W*H,s])*DW0_hat)',[R3*W,H])*V0)',[R2*R3,W]))'; % [W,r*r]
    GF3 = (NN * reshape((reshape((reshape(Mk,[W*H,LL])*W0)',[R3*W,H])*V0)',[R2*R3,W]))';
    
    Ah = reshape(Ah',[R1,r*r]);
    H1 = U0_hat'*YF1+U0'*ZF2+((mu+eta)/2)*U0'*GF3+lambda*Ah;            
    Ak = CG1_sub( FTF1,FTF2,((mu+eta)/2)*FTF3,U0,U0_hat,lambda,H1,Ah,n );
    H2 = PTx( YF1,BW,s0,sf )*Ak'+ZF2*Ak'+((mu+eta)/2)*GF3*Ak'+lambda*U0;
    Uk = CG2_sub( FTF1,FTF2,((mu+eta)/2)*FTF3,Ak,H2,U0,sf,s0,BW,lambda,n );
    Ak = Ah + gamma*(Ak-Ah);   Uk = U0 + gamma*(Uk-U0); 
    
    Uk1 = ifft(fft(Uk).*repmat(BW,[1 size(Uk,2)]));   Uk_hat = Uk1(s0:sf:end,:); 
    Ak = reshape(Ak,[R1*r,r])';                       Ah = reshape(Ah,[R1*r,r])';
    
    %% Update Bh and V ...
    NN = reshape(permute(reshape(reshape(Ak,[r*R1,r])*Ch,[r,R1,R3,r]),[1,4,3,2]),[r*r,R3*R1]);
    
    FTF1 = reshape(reshape(reshape(reshape(NN,[r*r*R3,R1])',[R1*r*r,R3])*(DW0')*DW0,[R1,r*r*R3])'*(Uk_hat)'*Uk_hat,[r*r,R3*R1]) * NN';  
    FTF2 = reshape(reshape(reshape(reshape(NN,[r*r*R3,R1])',[R1*r*r,R3])*(DW0_hat')*DW0_hat,[R1,r*r*R3])'*(Uk)'*Uk,[r*r,R3*R1]) * NN';
    FTF3 = reshape(reshape(reshape(reshape(NN,[r*r*R3,R1])',[R1*r*r,R3])*(W0')*W0,[R1,r*r*R3])'*(Uk)'*Uk,[r*r,R3*R1]) * NN';  
    YF1 = reshape(reshape(reshape(Y,[w*h,L])*DW0,[w,h*R3])'*Uk_hat,[h,R3*R1]) * NN';
    ZF2 = reshape(reshape(reshape(Z,[W*H,s])*DW0_hat,[W,H*R3])'*Uk,[H,R3*R1]) * NN';
    GF3 = reshape(reshape(reshape(Mk,[W*H,LL])*W0,[W,H*R3])'*Uk,[H,R3*R1]) * NN';
    
    Bh = reshape(Bh',[R2,r*r]);
    H1 = V0_hat'*YF1+V0'*ZF2+((mu+eta)/2)*V0'*GF3+lambda*Bh;            
    Bk = CG1_sub( FTF1,FTF2,((mu+eta)/2)*FTF3,V0,V0_hat,lambda,H1,Bh,n );
    H2 = PTx( YF1,BH,s0,sf )*Bk'+ZF2*Bk'+((mu+eta)/2)*GF3*Bk'+lambda*V0;
    Vk = CG2_sub( FTF1,FTF2,((mu+eta)/2)*FTF3,Bk,H2,V0,sf,s0,BH,lambda,n );
    Bk = Bh + gamma*(Bk-Bh);    Vk = V0 + gamma*(Vk-V0);
    
    Vk1 = ifft(fft(Vk).*repmat(BH,[1 size(Vk,2)]));   Vk_hat = Vk1(s0:sf:end,:); 
    Bk = reshape(Bk,[R2*r,r])';                       Bh = reshape(Bh,[R2*r,r])';
    
    %% Update Ch and W ...
    NN = reshape(permute(reshape(reshape(Bk,[r*R2,r])*Ak,[r,R2,R1,r]),[1,4,3,2]),[r*r,R1*R2]);
    
    FTF1 = reshape(reshape(reshape(reshape(NN,[r*r*R1,R2])',[R2*r*r,R1])*(Uk_hat)'*Uk_hat,[R2,r*r*R1])'*(Vk_hat)'*Vk_hat,[r*r,R1*R2]) * NN'; 
    FTF2 = reshape(reshape(reshape(reshape(NN,[r*r*R1,R2])',[R2*r*r,R1])*(Uk)'*Uk,[R2,r*r*R1])'*(Vk)'*Vk,[r*r,R1*R2]) * NN'; 
    YF1 = reshape(reshape(reshape(Y,[w,h*L])'*Uk_hat,[h,L*R1])'*Vk_hat,[L,R1*R2]) * NN';
    ZF2 = reshape(reshape(reshape(Z,[W,H*s])'*Uk,[H,s*R1])'*Vk,[s,R1*R2]) * NN';
    GF3 = reshape(reshape(reshape(Mk,[W,H*LL])'*Uk,[H,LL*R1])'*Vk,[LL,R1*R2]) * NN';
    
    FTF3 = FTF2;        Ch = reshape(Ch',[R3,r*r]);     
    
    H1 = DW0'*YF1+DW0_hat'*ZF2+((mu+eta)/2)*W0'*GF3+lambda*Ch;        
    Ck = CG11_sub( FTF1,FTF2,((mu+eta)/2)*FTF3,W0,DW0,DW0_hat,lambda,H1,Ch,n ); % ע��W0��W0_hat������λ��
    H2 = D'*YF1*Ck'+(T*D)'*ZF2*Ck'+((mu+eta)/2)*GF3*Ck'+lambda*W0;         
    Wk = CG3_sub( FTF1,FTF2,((mu+eta)/2)*FTF3,Ck,H2,W0,lambda,T,D,n);
    Ck = Ch + gamma*(Ck-Ch);     Wk = W0 + gamma*(Wk-W0);
    
    DWk = D*Wk;                  DWk_hat = T*DWk;
    Ck = reshape(Ck,[R3*r,r])';  Ch = reshape(Ch,[R3*r,r])';
   
    %% Next iteration
    relA = norm(Ah-Ak)/norm(Ah);    relB = norm(Bh-Bk)/norm(Bh);    relC = norm(Ch-Ck)/norm(Ch); 
    dX = max([relA,relB,relC]);
    if dX < 0.1
        fprintf('sub1_iteration = %d \n',iter);
        break;
    end
    %mu = max(0.9*mu,1e-5);
    
    Ah = Ak;            Bh = Bk;            Ch = Ck; 
    U0 = Uk;            V0 = Vk;            W0 = Wk;
    U0_hat = Uk_hat;    V0_hat = Vk_hat;    DW0 = DWk;    DW0_hat = DWk_hat;
end

%% Return data
A_hat = reshape(Ak',[R1,r,r]);   %A_h0 = reshape(Ah',[R1,r,r]);
B_hat = reshape(Bk, [r,R2,r]);   %B_h0 = reshape(Bh, [r,R2,r]);
C_hat = reshape(reshape(Ck,[r*R3,r])',[r,r,R3]);    
%C_h0 = reshape(reshape(Ch,[r*R3,r])',[r,r,R3]);  

Core = Triple_product(A_hat,B_hat,C_hat);
%Core0 = Triple_product(A_h0,B_h0,C_h0);
Tur  = double(ttm(ttm(ttm(tensor(Core),Uk,1),Vk,2),Wk,3));
%Tur0  = double(ttm(ttm(ttm(tensor(Core0),U0,1),V0,2),W0,3));
ABC{1} = A_hat;  ABC{2} = B_hat;  ABC{3} = C_hat;
UVW{1} = U0;     UVW{2} = V0;     UVW{3} = W0;
