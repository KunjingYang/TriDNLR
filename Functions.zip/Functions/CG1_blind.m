function P = CG1_blind( FTF1,Ak,H,P0,mu,cg_iter )
% optimize the dictionaries via Conjugate gradient 
 r0 = P0*Ak*FTF1*Ak'+mu*P0-H;  
 p0 = -r0;
 for i = 1:cg_iter
     Ap = p0*Ak*FTF1*Ak'+mu*p0; % AP
     pp1 = p0(:)'*Ap(:);

     a = (r0(:)')*r0(:)/pp1;
     P = P0+a*p0;
     r1 = r0+a*Ap;
     b1 = (r1(:)'*r1(:))/(r0(:)'*r0(:));
     p1 = -r1+b1*p0;
    
     p0 = p1;
     r0 = r1;
     P0=P;
     if norm(r0)<=0.01
         break;
     end
 end
 
 
