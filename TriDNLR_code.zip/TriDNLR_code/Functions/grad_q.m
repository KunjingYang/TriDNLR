function y = grad_q(S,D,Y,Z,BW,BH,sf,s0,T,delta)
[M,N,L] = size(S);
y = zeros(M,N,L);
E1 = eye(M); E2 = eye(N);
E1 = ifft( fft(E1).*repmat(BW,[1 size(E1,2)])); PE1 = E1(s0:sf:end,:); 
E2 = ifft(fft(E2).*repmat(BH,[1 size(E2,2)]));  PE2 = E2(s0:sf:end,:);
for k = 1:L
    delta_S = zeros(M,N,L);
    delta_S(:,:,k) = delta;
    y(:,:,k) = (obj_q(S+delta_S,D,PE1,PE2,T,Y,Z)-obj_q(S,D,PE1,PE2,T,Y,Z))/delta;
end

