function [ E ] = CG11_sub( FTF1,FTF2,FTF3,W,DW,DW_hat,mu,H,E0,cg_iter )
% optimize the dictionaries via Conjugate gradient 
 WTW = W'*W;
 DWTDW = DW'*DW;
 PDWTPDW = DW_hat'*DW_hat;
 r0 = DWTDW*E0*FTF1+PDWTPDW*E0*FTF2+WTW*E0*FTF3+mu*E0-H;  % ��ʼ���в�
 p0 = -r0;
 for i=1:cg_iter
    Ap = DWTDW*p0*FTF1+PDWTPDW*p0*FTF2+WTW*p0*FTF3+mu*p0;
    pp1 = p0(:)'*Ap(:);

    a=(r0(:)')*r0(:)/pp1;
         E=E0+a*p0;
         r1=r0+a*Ap;
         
         b1=(r1(:)'*r1(:))/(r0(:)'*r0(:));
         p1=-r1+b1*p0;
     p0=p1;
     r0=r1;
     E0=E;
     if norm(r0)<=0.01
         break;
     end
 end