function X = Triple_product(A,B,C)
% A��R^{n_1��r��r}
% B��R^{r��n_2��r}
% C��R^{r��r��n_3}
% S��R^{n_1��n_2��n_3}
%fprintf('\n Triple product is running ...   \n');

[n1,r1,r11] = size(A);
[r2,n2,r22] = size(B);
[r3,r33,n3] = size(C);

if r1 ~= r11 || r2 ~= r22 || r3 ~= r33
    print(' A,B or C is not square! ');
end
if r1 ~= r2 || r2 ~= r3 || r3 ~= r1
    print('the size of A,B or C are not matched! ');
else
    r = r1;
end
A = permute(A,[1,3,2]);
Ah = Unfold(A,size(A),1);
B = permute(B,[2,1,3]);
Bh = Unfold(B,size(B),3);
% C = permute(C,[2,1,3]);
Ch = Unfold(C,size(C),3)';
X = Ah*(kron(eye(r),Bh))*(kron(Ch,eye(n2)));
% X = Ah*kron(Ch,Bh);
X = reshape(X,n1,n2,n3);

