function [Tur,ABC,r] =  Sub1_TriBFus_auto(Y,Z,T,P3,BW,BH,sf,s0,mu,eta,par,Ds,abc,n)
% fprintf(' Sub1_TriBFus is running ... ');
gamma = par.gamma; lambda = par.lambda; tau = par.tau;
mut = (mu+eta)/2; muc = 4;
r= par.r;  r1=r; r3=r; mm = r; r_max=par.r_max;

%% Initialization
[w,h,L] = size(Y); [W,H,s] = size(Z);
L1 = size(Ds,2);
R1 = W;     R2 = H;      R3 = L1;

E1 = eye(W); E11 = ifft( fft(E1).*repmat(BW,[1 W])); E1_hat = E11(s0:sf:end,:);
E2 = eye(H); E22 = ifft(fft(E2).*repmat(BH,[1 H]));  E2_hat = E22(s0:sf:end,:);
E3 = eye(L1);PDs = P3*Ds;

A_hat = abc{1};       Ah = reshape(A_hat,[r3,R1*r]);
B_hat = abc{2};       Bh = reshape(B_hat,[r1,R2*r3]);
C_hat = abc{3};       Ch = reshape(C_hat,[r,R3*r1]);
Dh = Ds;
%% Main iterate
for iter=1:100
    %fprintf(' Sub1_iteration: %d   ',iter);
    %% Update Ah and U ...
    NN = reshape(permute(reshape(reshape(Ch,[r*R3,r1])*Bh,[r,R3,R2,r3]),[1,4,3,2]),[r*r3,R2*R3]);
    
    FTF1 = reshape(reshape(reshape(reshape(NN,[r*r3*R2,R3])',[R3*r*r3,R2])*(E2_hat')*E2_hat,[R3,r*r3*R2])'*(Ds')*Ds,[r*r3,R2*R3]) * NN';  
    FTF2 = reshape(reshape(reshape(reshape(NN,[r*r3*R2,R3])',[R3*r*r3,R2]),[R3,r*r3*R2])'*(PDs')*PDs,[r*r3,R2*R3]) * NN';
    FTF3 = reshape(reshape(reshape(reshape(NN,[r*r3*R2,R3])',[R3*r*r3,R2]),[R3,r*r3*R2])',[r*r3,R2*R3]) * NN';
    YF1 = (NN * reshape((reshape((reshape(Y,[w*h,L])*Ds)',[R3*w,h])*E2_hat)',[R2*R3,w]))';
    ZF2 = (NN * reshape((reshape((reshape(Z,[W*H,s])*PDs)',[R3*W,H]))',[R2*R3,W]))';
    TF3 = (NN * reshape((reshape((reshape(T,[W*H,L1]))',[R3*W,H]))',[R2*R3,W]))';
     
    Ah = reshape(Ah',[R1,r*r3]);
    H1 = E1_hat'*YF1+tau*ZF2+mut/2*TF3+lambda*Ah; 
    Ak = CG1_sub( FTF1,FTF2,(mut/2)*FTF3,E1,E1_hat,lambda,H1,Ah,n );
    Ak = Ah + gamma*(Ak-Ah); 
    Ak = reshape(Ak,[R1*r,r3])';       Ah = reshape(Ah,[R1*r,r3])';
    
    %% Update Bh and V ...
    NN = reshape(permute(reshape(reshape(Ak,[r3*R1,r])*Ch,[r3,R1,R3,r1]),[1,4,3,2]),[r3*r1,R3*R1]);
    
    FTF1 = reshape(reshape(reshape(reshape(NN,[r3*r1*R3,R1])',[R1*r3*r1,R3])*(Ds')*Ds,[R1,r3*r1*R3])'*(E1_hat)'*E1_hat,[r3*r1,R3*R1]) * NN';  
    FTF2 = reshape(reshape(reshape(reshape(NN,[r3*r1*R3,R1])',[R1*r3*r1,R3])*(PDs')*PDs,[R1,r3*r1*R3])',[r3*r1,R3*R1]) * NN';
    FTF3 = reshape(reshape(reshape(reshape(NN,[r3*r1*R3,R1])',[R1*r3*r1,R3]),[R1,r3*r1*R3])',[r3*r1,R3*R1]) * NN';  
    YF1 = reshape(reshape(reshape(Y,[w*h,L])*Ds,[w,h*R3])'*E1_hat,[h,R3*R1]) * NN';
    ZF2 = reshape(reshape(reshape(Z,[W*H,s])*PDs,[W,H*R3])',[H,R3*R1]) * NN';
    TF3 = reshape(reshape(reshape(T,[W*H,L1]),[W,H*R3])',[H,R3*R1]) * NN';
    
    Bh = reshape(Bh',[R2,r1*r3]);
    H1 = E2_hat'*YF1+tau*ZF2+(mut/2)*TF3+lambda*Bh;            
    Bk = CG1_sub( FTF1,FTF2,(mut/2)*FTF3,E2,E2_hat,lambda,H1,Bh,n );
    Bk = Bh + gamma*(Bk-Bh);  
    Bk = reshape(Bk,[R2*r3,r1])';         
    Bh = reshape(Bh,[R2*r3,r1])';
    
    %% Update Ch and W ...
    NN = reshape(permute(reshape(reshape(Bk,[r1*R2,r3])*Ak,[r1,R2,R1,r]),[1,4,3,2]),[r1*r,R1*R2]);
    
    FTF1 = reshape(reshape(reshape(reshape(NN,[r1*r*R1,R2])',[R2*r1*r,R1])*(E1_hat)'*E1_hat,[R2,r1*r*R1])'*(E2_hat)'*E2_hat,[r1*r,R1*R2]) * NN'; 
    FTF2 = reshape(reshape(reshape(reshape(NN,[r1*r*R1,R2])',[R2*r1*r,R1]),[R2,r1*r*R1])',[r1*r,R1*R2]) * NN'; 
    YF1 = reshape(reshape(reshape(Y,[w,h*L])'*E1_hat,[h,L*R1])'*E2_hat,[L,R1*R2]) * NN';
    ZF2 = reshape(reshape(reshape(Z,[W,H*s])',[H,s*R1])',[s,R1*R2]) * NN';
    TF3 = reshape(reshape(reshape(T,[W,H*L1])',[H,L1*R1])',[L1,R1*R2]) * NN';
    FTF3 = FTF2;        
    
    Ch = reshape(Ch',[R3,r1*r]);     
    H1 = Ds'*YF1+tau*PDs'*ZF2+(mut/2)*TF3+lambda*Ch;        
    Ck = CG11_sub( FTF1,FTF2,(mut/2)*FTF3,E3,Ds,PDs,lambda,H1,Ch,n ); % ע��W0��W0_hat������λ��
%     H2 = YF1*Ck'+tau*P3'*ZF2*Ck'+muc/2*Dh;      
%     Ds = CG3_sub( FTF1,tau*FTF2,0,Ck,H2,Dh,muc/2,P3,eye(L),n);
%     Dh = svso(Ds,alpha/muc);
    
    Ck = Ch + gamma*(Ck-Ch);
    Ck = reshape(Ck,[R3*r1,r])';  Ch = reshape(Ch,[R3*r1,r])';
   
    %% Next iteration
    relA = norm(Ah-Ak)/norm(Ah);    relB = norm(Bh-Bk)/norm(Bh);    relC = norm(Ch-Ck)/norm(Ch); 
    dX = max([relA,relB,relC]);
    if dX < 0.1
        break;
    else
       %fprintf('max_rel=%0.4f \n',dX);
       r = min(r+1,r_max); r1= r; r3 =r;   mm = mm+1;
       Ah = zeros(r3,R1*r); Bh = zeros(r1,R2*r3); Ch = zeros(r1,R3*r1);
       if r <r_max  || mm == r_max
            Ah(1:r3-1,1:R1*(r-1))=Ak;
            Bh(1:r1-1,1:R2*(r3-1))=Bk;
            Ch(1:r-1,1:R3*(r1-1))=Ck;
       else
            Ah = Ak;            Bh = Bk;            Ch = Ck; 
       end
    end
    
end

%% Return data
A_hat = reshape(Ak',[R1,r,r3]);
B_hat = reshape(Bk, [r1,R2,r3]);   
C_hat = reshape(reshape(Ck,[r*R3,r1])',[r1,r,R3]);    

Tur = Triple_product(A_hat,B_hat,C_hat);
ABC{1} = A_hat;  ABC{2} = B_hat;  ABC{3} = C_hat;
