function grad=tidu(A,gamma) %%����ֵ��ȥMCP�������ݶ�

Nway=size(A);
% V=reshape(x,prod(Nway),1);
% for i=1:prod(Nway)
%     if abs(V(i))<=gamma
%         V(i)=V(i)/gamma;
%     else
%         V(i)=sign(V(i));
%     end
% end
% grad=reshape(V,Nway);

grad=zeros(Nway);
B=zeros(Nway)+gamma;
C=abs(A)-B;
C1=find(C>0);
C2=find(C<=0);
grad(C1)=sign(A(C1));
grad(C2)=A(C2)/gamma;
