function G = Sub2_Nonlocal_corr(S,Gk,mu,para,eta)
%fprintf(' Sub2_Nonlocal is running ... ');
tao = para.tao;  gama = para.gama;
%%  
    [W,H,L] = size(S);
    patch_size = 8;
    overlap    = 4;
    K = 48; a = K/8;
    bparams.block_sz   = [patch_size, patch_size];
    bparams.overlap_sz = [overlap overlap];
    num1 = (W-patch_size)/(patch_size-overlap)+1;
    num2 = (H-patch_size)/(patch_size-overlap)+1;
    bparams.block_num = [num1 num2]; 
    fkmeans_omaxpt.careful = 1;
    
    PK=zeros(W,H,L); 
    L_fix_fft=fft(Gk,[],3);
    for j = 1:L
        [U,B,V] = svd(L_fix_fft(:,:,j),'econ');
        B = diag(B);
        B = tidu(B,gama);
        r = length(find(B~=0));
        B = B(1:r);
        PK(:,:,j) = U(:,1:r)*diag(B)*V(:,1:r)';
    end
    PK = ifft(PK,[],3);  % grad H
    
    
        
%%

        N0 = (eta*Gk+tao*PK+mu*S)/(eta+mu);
        Z_block = ExtractBlocks(N0, bparams);
        predenoised_blocks = ExtractBlocks(N0, bparams);
    Y2 = Unfold(predenoised_blocks,size(predenoised_blocks),4);
    [label ] = fkmeans(Y2,K,fkmeans_omaxpt);
        Z_block_new = zeros(size(Z_block));
        %max_lable = max(label);
      %  spmd
        for    mn = 1:K  %(labindex-1)*a+1:labindex*a
            gg = label == mn;
            XES=predenoised_blocks(:,:,:,gg);
            [a, b, c, d ]=size(XES);
            XES = reshape(XES,[a b c*d]);
            N11 = prox_tnn(XES,tao/(mu*tao+eta));
            N11=reshape(N11,[a b c d]); 
            Z_block_new(:,:,:,gg)=N11;
        end
     %   end
     %  Z_block_new =Z_block_new{1}+Z_block_new{2}+Z_block_new{3}+Z_block_new{4}+...
    %       Z_block_new{5}+Z_block_new{6}+Z_block_new{7}+Z_block_new{8};
        
         G = JointBlocks(Z_block_new, bparams);  
       %  fprintf('\n');
